GnuPGのインフォグラフィックのソース
===================================

Free Software Foundationの『電子メール自己防衛』ガイドで使っているインフォグラフィックのソースファイルです。
ガイド自体は<http://EmailSelfDefense.fsf.org>をアクセスしてください。

ライセンス
----------

Copyright (c) 2014 Free Software Foundation, Inc.

<http://creativecommons.org/licenses/by/4.0/legalcode>

Licensed under the Creative Commons Attribution license (CC-BY). See full
source and attribution text at the above site.
