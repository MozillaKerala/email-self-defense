Πρωτότυπα αρχεία για το infographic του GnuPG 
==================================

Αυτά είναι τα πρωτότυπα γραφικά για τον Οδηγό Αυτοάμυνας με Email από την 
Free Software Foundation, ο οποίος είναι διαθέσιμος στο <http://EmailSelfDefense.fsf.org>.

Άδεια χρήσης
-------

Copyright (c) 2014 Free Software Foundation, Inc.

<http://creativecommons.org/licenses/by/4.0/legalcode>

Παρέχεται με άδεια Creative Commons Αναφορά Δημιουργού (CC-BY). Δείτε το πλήρες πρωτότυπο 
και το κείμενο αναφοράς δημιουργού στο παραπάνω site.
