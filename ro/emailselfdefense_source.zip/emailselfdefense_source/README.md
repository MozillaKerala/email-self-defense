Source files for GnuPG infographic
==================================

These are the source graphics for the Email Self-Defense guide from the
Free Software Foundation, available at <http://EmailSelfDefense.fsf.org>.

License
-------

Copyright (c) 2014 Free Software Foundation, Inc.

<http://creativecommons.org/licenses/by/4.0/legalcode>

Licensed under the Creative Commons Attribution license (CC-BY). See full
source and attribution text at the above site.
