Arquivos-fonte para o infográfico do GnuPG
==========================================

Essas são as fontes gráficas do guia Autodefesa no E-mail da Free Software
Foundation, disponível em <http://EmailSelfDefense.fsf.org>.

Licença
-------

Copyright (c) 2014 Free Software Foundation, Inc.

<http://creativecommons.org/licenses/by/4.0/legalcode>

Disponível sob a licença Creative Commons Atribuição (CC-BY). Veja o texto
completo da licença no site acima.
