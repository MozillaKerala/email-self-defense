Fichiers sources pour le guide HTML de GnuPG
============================================

Dans ce répertoire, vous trouverez la source de l'infographie pour le
guide « Autodéfense courriel » de la FSF (traduction en français de Email
Self-Defense), qui est disponible sur <http://EmailSelfDefense.fsf.org>.

Licence
-------

Copyright (c) 2014 Free Software Foundation, Inc.

Diffusé sous licence Creative Commons Attribution (CC-BY). Voir la source
complète et le texte d'attribution de paternité sur le site cité plus haut.
